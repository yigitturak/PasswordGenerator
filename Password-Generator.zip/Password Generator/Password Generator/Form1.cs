﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Resources;
namespace Password_Generator
{
    public partial class PassGen : Form
    {
        private string alphabetLower = "abcdefghijklmnopqrstuvwxyz";
        private string alphabetUpper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        private string numberChar = "0123456789";
        private string specialChar = "!#+$%&=?*-.,><;:";
        private string turkishChar = "ğĞıİşŞçÇöÖüÜ";
        private string englishChar = "gGiIsScCoOuU";
        private string encrytedChar = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@!#+$%&=?*-.,><;:";
        StreamWriter writer;
        StreamReader reader;
        

        public PassGen()
        {
            InitializeComponent();
        }


        private void btnGenerator_Click(object sender, EventArgs e)
        {
            long random = randomNumber();
            string temp = convertToEnglishChar(txtBoxPass.Text);
            if (chkBoxUpperLower.Checked && getNumberUpperChar(temp) < 3)
                temp = upperLower(temp, random);
            if (chkBoxNumber.Checked && getNumber(temp) < 3)
                temp = convertToNumber(temp);
            if (chkBoxSpecial.Checked && getNumberSpecialChar(temp) < 2)
                temp = specialCharacter(temp);

            txtBoxGenerate.Text = temp;
        }
        

        private long randomNumber()
        {
            long seed = System.DateTime.Now.Second;
            long a = (long)Math.Pow(7, 5);
            long mod = (long)Math.Pow(2, 31) - 1;
            long result = 0;

            result = (a * seed) % mod;
            return result;
        }


        #region Generate
        private string upperLower(String pass, long random)
        {
            string result=pass;
            int binary = (int)(random % 2);
            int i=0;
            if (binary == 0)
            {
                while(i < result.Length)
                {
                    for (int j = 0; j < this.alphabetLower.Length; j++)
                    {
                        if (result[i] == this.alphabetLower[j])
                        {
                            result=result.Replace(result[i], this.alphabetUpper[j]);
                        }
                    }
                    i += 2;
                }
            }
            else
            {
                i = 1;
                while (i < result.Length)
                {
                    for (int j = 0; j < this.alphabetLower.Length; j++)
                    {
                        if (result[i] == this.alphabetLower[j])
                        {
                            result = result.Replace(result[i], this.alphabetUpper[j]);
                        }
                    }
                    i += 2;
                }
            }
            return result;
        }

        private string convertToNumber(string pass)
        {
            string result = pass;

            for (int i = 0; i < result.Length; i++)
            {
                if (result[i] == 'S')
                    result = result.Replace(result[i], '5');
                if (result[i] == 'l')
                    result = result.Replace(result[i], '1');
                if (result[i] == 'E')
                    result = result.Replace(result[i], '3');
                if (result[i] == 'g')
                    result = result.Replace(result[i], '9');
                if (result[i] == 'B')
                    result = result.Replace(result[i], '8');
                if (result[i] == 'b')
                    result = result.Replace(result[i], '6');
                if (result[i] == 'o' || result[i] == 'O')
                    result = result.Replace(result[i], '0');
            }

                return result;
        }

        private string specialCharacter(string pass)
        {
            string result = pass;
            for (int i = 0; i < result.Length; i++)
            {
                if (result[i] == 'a' || result[i] == 'A')
                    result = result.Replace(result[i], '@');
                if (result[i] == 'i' || result[i] == 'I')
                    result = result.Replace(result[i], '!');
                if (result[i] == 'x' || result[i] == 'X')
                    result = result.Replace(result[i], '*');
                if (result[i] == 'h' || result[i] == 'H')
                    result = result.Replace(result[i], '#');
                if (result[i] == 's')
                    result = result.Replace(result[i], '$');
                if (result[i] == 't')
                    result = result.Replace(result[i], '+');
            }
            return result;
        }

        private string convertToEnglishChar(string pass)
        {
            string result = pass;
            for (int i = 0; i < result.Length; i++)
            {
                for (int j = 0; j < this.turkishChar.Length; j++)
                {
                    if (result[i] == this.turkishChar[j])
                        result = result.Replace(result[i], this.englishChar[j]);
                }
            }
            return result;
        }

        private int getNumberUpperChar(string pass)
        {
            int result=0;
            for (int i = 0; i < pass.Length; i++)
            {
                for (int j = 0; j < this.alphabetUpper.Length; j++)
                {
                    if (pass[i] == this.alphabetUpper[j])
                        result++;
                }
            }
            return result;
        }
        private int getNumber(string pass)
        {
            int result = 0;
            for (int i = 0; i < pass.Length; i++)
            {
                for (int j = 0; j < this.numberChar.Length; j++)
                {
                    if (pass[i] == this.numberChar[j])
                        result++;
                }
            }
            return result;
        }
        private int getNumberSpecialChar(string pass)
        {
            int result = 0;
            for (int i = 0; i < pass.Length; i++)
            {
                for (int j = 0; j < this.specialChar.Length; j++)
                {
                    if (pass[i] == this.specialChar[j])
                        result++;
                }
            }
            return result;
        }
        #endregion


        #region SavePass
        private string encryptingPass(string pass, string key)
        {
            string result = "", tempPass = pass, tempKey = key;
            int indexPass = 0, indexKey = 0;
            for (int i = 0; i < tempPass.Length; i++)
            {
                indexPass = encrytedChar.IndexOf(tempPass[i]);
                indexKey = encrytedChar.IndexOf(tempKey[(i % tempKey.Length)]);
                result += encrytedChar[((indexKey + indexPass) % encrytedChar.Length)];
            }
            return result;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtBoxSave.Text != "" && txtBoxGenerate.Text != "" && txtBoxKeySave.Text != "")
            {
                this.writer = new StreamWriter(".\\" + txtBoxSave.Text);
                txtBoxKeySave.Text = convertToEnglishChar(txtBoxKeySave.Text);
                this.writer.Write(encryptingPass(txtBoxGenerate.Text, txtBoxKeySave.Text));
                this.writer.Close();
                MessageBox.Show("your password was saved", "Save");
            }
            else
                MessageBox.Show("Please generate a password, give a name file and enter a key for encrypte");
            
        }
        #endregion


        #region OpenPass
        private string decryptingPass(string encrypted, string key)
        {
            string result = "", tempEnc = encrypted, tempKey = key;
            int indexEnc = 0, indexKey = 0;
            for (int i = 0; i < tempEnc.Length; i++)
            {
                indexEnc = encrytedChar.IndexOf(tempEnc[i]);
                indexKey = encrytedChar.IndexOf(tempKey[(i % tempKey.Length)]);
                if (indexEnc - indexKey < 0)
                {
                    result += encrytedChar[(indexEnc - indexKey + encrytedChar.Length)];
                }
                else
                    result += encrytedChar[((indexEnc - indexKey) % encrytedChar.Length)];
            }
            return result;
        }
        private void btnOpen_Click(object sender, EventArgs e)
        {
            string tempText = "";
            if (txtBoxOpen.Text != "" && txtBoxKey.Text != "")
            {
                this.reader = new StreamReader(".\\" + txtBoxOpen.Text);
                txtBoxKey.Text = convertToEnglishChar(txtBoxKey.Text);
                tempText = this.reader.ReadLine();
                txtBoxOpenPass.Text = tempText;
                txtBoxOpenPass.Text = decryptingPass(tempText, txtBoxKey.Text);
                this.reader.Close();
            }
            else
                MessageBox.Show("Please give a name file and enter a key for decrypte");
            
        }
        #endregion


        #region ToolStripMenu
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("It was written by Yigit Turak\n\nContact: yturak(at)yigitturak(dot)com","About");
        }
        #endregion

    }
}
