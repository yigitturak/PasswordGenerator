﻿namespace Password_Generator
{
    partial class PassGen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PassGen));
            this.chkBoxUpperLower = new System.Windows.Forms.CheckBox();
            this.chkBoxNumber = new System.Windows.Forms.CheckBox();
            this.chkBoxSpecial = new System.Windows.Forms.CheckBox();
            this.txtBoxPass = new System.Windows.Forms.TextBox();
            this.txtBoxGenerate = new System.Windows.Forms.TextBox();
            this.btnGenerator = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grpBoxSave = new System.Windows.Forms.GroupBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblSave = new System.Windows.Forms.Label();
            this.txtBoxSave = new System.Windows.Forms.TextBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.grpBoxOpen = new System.Windows.Forms.GroupBox();
            this.lblKey = new System.Windows.Forms.Label();
            this.txtBoxKey = new System.Windows.Forms.TextBox();
            this.lblOpen = new System.Windows.Forms.Label();
            this.btnOpen = new System.Windows.Forms.Button();
            this.txtBoxOpenPass = new System.Windows.Forms.TextBox();
            this.txtBoxOpen = new System.Windows.Forms.TextBox();
            this.lblKeySave = new System.Windows.Forms.Label();
            this.txtBoxKeySave = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.grpBoxSave.SuspendLayout();
            this.grpBoxOpen.SuspendLayout();
            this.SuspendLayout();
            // 
            // chkBoxUpperLower
            // 
            this.chkBoxUpperLower.AutoSize = true;
            this.chkBoxUpperLower.Location = new System.Drawing.Point(21, 54);
            this.chkBoxUpperLower.Name = "chkBoxUpperLower";
            this.chkBoxUpperLower.Size = new System.Drawing.Size(93, 17);
            this.chkBoxUpperLower.TabIndex = 0;
            this.chkBoxUpperLower.Text = "Upper - Lower";
            this.chkBoxUpperLower.UseVisualStyleBackColor = true;
            // 
            // chkBoxNumber
            // 
            this.chkBoxNumber.AutoSize = true;
            this.chkBoxNumber.Location = new System.Drawing.Point(21, 77);
            this.chkBoxNumber.Name = "chkBoxNumber";
            this.chkBoxNumber.Size = new System.Drawing.Size(87, 17);
            this.chkBoxNumber.TabIndex = 1;
            this.chkBoxNumber.Text = "Number [0-9]";
            this.chkBoxNumber.UseVisualStyleBackColor = true;
            // 
            // chkBoxSpecial
            // 
            this.chkBoxSpecial.AutoSize = true;
            this.chkBoxSpecial.Location = new System.Drawing.Point(21, 100);
            this.chkBoxSpecial.Name = "chkBoxSpecial";
            this.chkBoxSpecial.Size = new System.Drawing.Size(110, 17);
            this.chkBoxSpecial.TabIndex = 2;
            this.chkBoxSpecial.Text = "Special Character";
            this.chkBoxSpecial.UseVisualStyleBackColor = true;
            // 
            // txtBoxPass
            // 
            this.txtBoxPass.Location = new System.Drawing.Point(13, 21);
            this.txtBoxPass.Name = "txtBoxPass";
            this.txtBoxPass.Size = new System.Drawing.Size(132, 20);
            this.txtBoxPass.TabIndex = 3;
            // 
            // txtBoxGenerate
            // 
            this.txtBoxGenerate.Location = new System.Drawing.Point(13, 136);
            this.txtBoxGenerate.Name = "txtBoxGenerate";
            this.txtBoxGenerate.ReadOnly = true;
            this.txtBoxGenerate.Size = new System.Drawing.Size(133, 20);
            this.txtBoxGenerate.TabIndex = 4;
            // 
            // btnGenerator
            // 
            this.btnGenerator.Location = new System.Drawing.Point(167, 18);
            this.btnGenerator.Name = "btnGenerator";
            this.btnGenerator.Size = new System.Drawing.Size(75, 23);
            this.btnGenerator.TabIndex = 5;
            this.btnGenerator.Text = "Generate";
            this.btnGenerator.UseVisualStyleBackColor = true;
            this.btnGenerator.Click += new System.EventHandler(this.btnGenerator_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(552, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.aboutToolStripMenuItem.Text = "&About...";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // grpBoxSave
            // 
            this.grpBoxSave.Controls.Add(this.lblKeySave);
            this.grpBoxSave.Controls.Add(this.txtBoxKeySave);
            this.grpBoxSave.Controls.Add(this.btnSave);
            this.grpBoxSave.Controls.Add(this.lblSave);
            this.grpBoxSave.Controls.Add(this.txtBoxSave);
            this.grpBoxSave.Controls.Add(this.btnGenerator);
            this.grpBoxSave.Controls.Add(this.txtBoxGenerate);
            this.grpBoxSave.Controls.Add(this.txtBoxPass);
            this.grpBoxSave.Controls.Add(this.chkBoxSpecial);
            this.grpBoxSave.Controls.Add(this.chkBoxNumber);
            this.grpBoxSave.Controls.Add(this.chkBoxUpperLower);
            this.grpBoxSave.Location = new System.Drawing.Point(12, 27);
            this.grpBoxSave.Name = "grpBoxSave";
            this.grpBoxSave.Size = new System.Drawing.Size(251, 227);
            this.grpBoxSave.TabIndex = 7;
            this.grpBoxSave.TabStop = false;
            this.grpBoxSave.Text = "Generate and Save";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(167, 178);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblSave
            // 
            this.lblSave.AutoSize = true;
            this.lblSave.Location = new System.Drawing.Point(10, 170);
            this.lblSave.Name = "lblSave";
            this.lblSave.Size = new System.Drawing.Size(35, 13);
            this.lblSave.TabIndex = 7;
            this.lblSave.Text = "Name";
            // 
            // txtBoxSave
            // 
            this.txtBoxSave.Location = new System.Drawing.Point(48, 167);
            this.txtBoxSave.Name = "txtBoxSave";
            this.txtBoxSave.Size = new System.Drawing.Size(98, 20);
            this.txtBoxSave.TabIndex = 6;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // grpBoxOpen
            // 
            this.grpBoxOpen.Controls.Add(this.lblKey);
            this.grpBoxOpen.Controls.Add(this.txtBoxKey);
            this.grpBoxOpen.Controls.Add(this.lblOpen);
            this.grpBoxOpen.Controls.Add(this.btnOpen);
            this.grpBoxOpen.Controls.Add(this.txtBoxOpenPass);
            this.grpBoxOpen.Controls.Add(this.txtBoxOpen);
            this.grpBoxOpen.Location = new System.Drawing.Point(289, 27);
            this.grpBoxOpen.Name = "grpBoxOpen";
            this.grpBoxOpen.Size = new System.Drawing.Size(251, 227);
            this.grpBoxOpen.TabIndex = 8;
            this.grpBoxOpen.TabStop = false;
            this.grpBoxOpen.Text = "Open Password";
            // 
            // lblKey
            // 
            this.lblKey.AutoSize = true;
            this.lblKey.Location = new System.Drawing.Point(6, 57);
            this.lblKey.Name = "lblKey";
            this.lblKey.Size = new System.Drawing.Size(25, 13);
            this.lblKey.TabIndex = 8;
            this.lblKey.Text = "Key";
            // 
            // txtBoxKey
            // 
            this.txtBoxKey.Location = new System.Drawing.Point(47, 54);
            this.txtBoxKey.Name = "txtBoxKey";
            this.txtBoxKey.Size = new System.Drawing.Size(98, 20);
            this.txtBoxKey.TabIndex = 7;
            // 
            // lblOpen
            // 
            this.lblOpen.AutoSize = true;
            this.lblOpen.Location = new System.Drawing.Point(6, 24);
            this.lblOpen.Name = "lblOpen";
            this.lblOpen.Size = new System.Drawing.Size(35, 13);
            this.lblOpen.TabIndex = 6;
            this.lblOpen.Text = "Name";
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(167, 18);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(75, 23);
            this.btnOpen.TabIndex = 5;
            this.btnOpen.Text = "Open";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // txtBoxOpenPass
            // 
            this.txtBoxOpenPass.Location = new System.Drawing.Point(13, 97);
            this.txtBoxOpenPass.Name = "txtBoxOpenPass";
            this.txtBoxOpenPass.ReadOnly = true;
            this.txtBoxOpenPass.Size = new System.Drawing.Size(132, 20);
            this.txtBoxOpenPass.TabIndex = 4;
            // 
            // txtBoxOpen
            // 
            this.txtBoxOpen.Location = new System.Drawing.Point(47, 21);
            this.txtBoxOpen.Name = "txtBoxOpen";
            this.txtBoxOpen.Size = new System.Drawing.Size(98, 20);
            this.txtBoxOpen.TabIndex = 3;
            // 
            // lblKeySave
            // 
            this.lblKeySave.AutoSize = true;
            this.lblKeySave.Location = new System.Drawing.Point(10, 196);
            this.lblKeySave.Name = "lblKeySave";
            this.lblKeySave.Size = new System.Drawing.Size(25, 13);
            this.lblKeySave.TabIndex = 10;
            this.lblKeySave.Text = "Key";
            // 
            // txtBoxKeySave
            // 
            this.txtBoxKeySave.Location = new System.Drawing.Point(47, 193);
            this.txtBoxKeySave.Name = "txtBoxKeySave";
            this.txtBoxKeySave.Size = new System.Drawing.Size(98, 20);
            this.txtBoxKeySave.TabIndex = 9;
            // 
            // PassGen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 266);
            this.Controls.Add(this.grpBoxOpen);
            this.Controls.Add(this.grpBoxSave);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "PassGen";
            this.Text = "Password Generator";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpBoxSave.ResumeLayout(false);
            this.grpBoxSave.PerformLayout();
            this.grpBoxOpen.ResumeLayout(false);
            this.grpBoxOpen.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkBoxUpperLower;
        private System.Windows.Forms.CheckBox chkBoxNumber;
        private System.Windows.Forms.CheckBox chkBoxSpecial;
        private System.Windows.Forms.TextBox txtBoxPass;
        private System.Windows.Forms.TextBox txtBoxGenerate;
        private System.Windows.Forms.Button btnGenerator;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.GroupBox grpBoxSave;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblSave;
        private System.Windows.Forms.TextBox txtBoxSave;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.GroupBox grpBoxOpen;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.TextBox txtBoxOpenPass;
        private System.Windows.Forms.TextBox txtBoxOpen;
        private System.Windows.Forms.Label lblKey;
        private System.Windows.Forms.TextBox txtBoxKey;
        private System.Windows.Forms.Label lblOpen;
        private System.Windows.Forms.Label lblKeySave;
        private System.Windows.Forms.TextBox txtBoxKeySave;
    }
}

